function insertImage() {
  const input = document.getElementById('imageInput');
  const file = input.files[0];
  if (!file) return alert('Pilih gambar terlebih dahulu');

  const reader = new FileReader();
  reader.onload = function(e) {
    const imgTag = `<img src="${e.target.result}" style="max-width:100%;"/>`;
    const content = document.getElementById('content');
    content.value += "\n" + imgTag + "\n";
  };
  reader.readAsDataURL(file);
}

function slugify(text) {
  return text.toLowerCase().trim().replace(/\s+/g, '-').replace(/[^\w\-]+/g, '');
}

function downloadArticle() {
  const title = document.getElementById('title').value.trim();
  const content = document.getElementById('content').value.trim();
  if (!title || !content) {
    alert("Judul dan konten tidak boleh kosong.");
    return;
  }

  const slug = slugify(title);
  const html = `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>${title}</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    body { font-family: sans-serif; padding: 20px; max-width: 700px; margin: auto; background: #fff; }
    img { max-width: 100%; }
  </style>
</head>
<body>
  <h1>${title}</h1>
  <div>${content}</div>
</body>
</html>`;

  const blob = new Blob([html], { type: 'text/html' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = `posts/${slug}.html`;
  link.click();
}
